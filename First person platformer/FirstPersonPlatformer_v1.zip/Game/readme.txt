Controls:
w : forward
a: left
d: right
s: backwards
spacebar: jump
left mouse button: dash

Goal: 
Jump over the astroids to reach the earth! But beware, the astroids will fall if you stand on them for too long.

Astroids: https://assetstore.unity.com/publishers/27658
Planet: https://assetstore.unity.com/publishers/9240
Game: https://thefourthsword.itch.io/